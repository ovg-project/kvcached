# LMCacheConnectorV1 Evidence

- run_id: plain_lmcache_hits_1
- collected_at_utc: 2026-05-12T10:55:00Z
- repo_dir: /root/kvcached
- run_dir: /root/kvcached/experiments/logs_lmcache_v1_debug/plain_lmcache_hits_1

## Git
## pd-disagg-LMCacheConnectorV1-1...origin/pd-disagg-LMCacheConnectorV1-1
434ebaf (HEAD -> pd-disagg-LMCacheConnectorV1-1, origin/pd-disagg-LMCacheConnectorV1-1) Add LMCache evidence collector
304fbe7 Refocus LMCache validation on bring-up
f350fbc Use long prompts for LMCache hit validation
ce57e43 Add LMCache PD disagg request metadata
dad9169 Fix LMCache harness vLLM serve args

## Key Classifiers
/root/kvcached/experiments/logs_lmcache_v1_debug/plain_lmcache_hits_1/decode.log:(EngineCore pid=5356) [32;20m[2026-05-12 10:45:36,260] LMCache INFO:[0m Reqid: cmpl-lmcache-disagg-b9ce47c757204610b4a936e34c8e96ca-0-bdbdcfbe, Total tokens 546, Inference Engine computed tokens: 0, LMCache hit tokens: 512, need to load: 512 [3m(vllm_v1_adapter.py:1327:lmcache.integration.vllm.vllm_v1_adapter)[0m
/root/kvcached/experiments/logs_lmcache_v1_debug/plain_lmcache_hits_1/decode.log:(EngineCore pid=5356) [32;20m[2026-05-12 10:45:36,283] LMCache INFO:[0m [req_id=cmpl-lmcache-disagg-b9ce47c757204610b4a936e34c8e96ca-0-bdbdcfbe] Retrieved 512 out of 512 required tokens (from 512 total tokens). size: 0.0137 gb, cost 2.7301 ms, throughput: 5.0079 GB/s; [3m(cache_engine.py:886:lmcache.v1.cache_engine)[0m
/root/kvcached/experiments/logs_lmcache_v1_debug/plain_lmcache_hits_1/decode.log:(EngineCore pid=5356) [32;20m[2026-05-12 10:45:36,670] LMCache INFO:[0m Reqid: cmpl-lmcache-disagg-1f12238e333b482aad96c01e94997536-0-a1681d39, Total tokens 545, Inference Engine computed tokens: 0, LMCache hit tokens: 512, need to load: 512 [3m(vllm_v1_adapter.py:1327:lmcache.integration.vllm.vllm_v1_adapter)[0m
/root/kvcached/experiments/logs_lmcache_v1_debug/plain_lmcache_hits_1/decode.log:(EngineCore pid=5356) [32;20m[2026-05-12 10:45:36,672] LMCache INFO:[0m [req_id=cmpl-lmcache-disagg-1f12238e333b482aad96c01e94997536-0-a1681d39] Retrieved 512 out of 512 required tokens (from 512 total tokens). size: 0.0137 gb, cost 0.3004 ms, throughput: 45.5173 GB/s; [3m(cache_engine.py:886:lmcache.v1.cache_engine)[0m
/root/kvcached/experiments/logs_lmcache_v1_debug/plain_lmcache_hits_1/prefill.log:(EngineCore pid=5363) [32;20m[2026-05-12 10:45:36,183] LMCache INFO:[0m [req_id=cmpl-lmcache-disagg-b9ce47c757204610b4a936e34c8e96ca-0-a43160d2] Stored 546 out of total 546 tokens. size: 0.0205 GB, cost 58.2575 ms, throughput: 0.3520 GB/s; offload_time: 2.6636 ms, put_time: 55.5547 ms [3m(cache_engine.py:552:lmcache.v1.cache_engine)[0m
/root/kvcached/experiments/logs_lmcache_v1_debug/plain_lmcache_hits_1/prefill.log:(EngineCore pid=5363) [32;20m[2026-05-12 10:45:36,620] LMCache INFO:[0m Reqid: cmpl-lmcache-disagg-1f12238e333b482aad96c01e94997536-0-bdd3b2e2, Total tokens 545, Inference Engine computed tokens: 0, LMCache hit tokens: 512, need to load: 512 [3m(vllm_v1_adapter.py:1327:lmcache.integration.vllm.vllm_v1_adapter)[0m
/root/kvcached/experiments/logs_lmcache_v1_debug/plain_lmcache_hits_1/prefill.log:(EngineCore pid=5363) [32;20m[2026-05-12 10:45:36,623] LMCache INFO:[0m [req_id=cmpl-lmcache-disagg-1f12238e333b482aad96c01e94997536-0-bdd3b2e2] Retrieved 512 out of 512 required tokens (from 512 total tokens). size: 0.0137 gb, cost 0.6766 ms, throughput: 20.2054 GB/s; [3m(cache_engine.py:886:lmcache.v1.cache_engine)[0m
/root/kvcached/experiments/logs_lmcache_v1_debug/plain_lmcache_hits_1/prefill.log:(EngineCore pid=5363) [32;20m[2026-05-12 10:45:36,650] LMCache INFO:[0m [req_id=cmpl-lmcache-disagg-1f12238e333b482aad96c01e94997536-0-bdd3b2e2] Stored 545 out of total 545 tokens. size: 0.0205 GB, cost 3.7669 ms, throughput: 5.4442 GB/s; offload_time: 0.3764 ms, put_time: 3.3587 ms [3m(cache_engine.py:552:lmcache.v1.cache_engine)[0m

## Request/Response Files
-rw-r--r-- 1 root root 2949 May 12 10:45 /root/kvcached/experiments/logs_lmcache_v1_debug/plain_lmcache_hits_1/request_1_request.json
-rw-r--r-- 1 root root  568 May 12 10:45 /root/kvcached/experiments/logs_lmcache_v1_debug/plain_lmcache_hits_1/request_1_response.json
-rw-r--r-- 1 root root 2944 May 12 10:45 /root/kvcached/experiments/logs_lmcache_v1_debug/plain_lmcache_hits_1/request_2_request.json
-rw-r--r-- 1 root root  572 May 12 10:45 /root/kvcached/experiments/logs_lmcache_v1_debug/plain_lmcache_hits_1/request_2_response.json
