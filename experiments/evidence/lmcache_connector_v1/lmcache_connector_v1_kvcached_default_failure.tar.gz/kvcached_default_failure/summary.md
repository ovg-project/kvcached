# LMCacheConnectorV1 Evidence

- run_id: kvcached_lmcache_hits_1
- collected_at_utc: 2026-05-12T10:56:43Z
- repo_dir: /root/kvcached
- run_dir: /root/kvcached/experiments/logs_lmcache_v1_debug/kvcached_lmcache_hits_1

## Git
## pd-disagg-LMCacheConnectorV1-1...origin/pd-disagg-LMCacheConnectorV1-1
434ebaf (HEAD -> pd-disagg-LMCacheConnectorV1-1, origin/pd-disagg-LMCacheConnectorV1-1) Add LMCache evidence collector
304fbe7 Refocus LMCache validation on bring-up
f350fbc Use long prompts for LMCache hit validation
ce57e43 Add LMCache PD disagg request metadata
dad9169 Fix LMCache harness vLLM serve args

## Key Classifiers
/root/kvcached/experiments/logs_lmcache_v1_debug/kvcached_lmcache_hits_1/prefill.log:(EngineCore pid=7814) ERROR 05-12 10:56:41 [core.py:1110] EngineCore encountered a fatal error.
/root/kvcached/experiments/logs_lmcache_v1_debug/kvcached_lmcache_hits_1/prefill.log:(EngineCore pid=7814) ERROR 05-12 10:56:41 [core.py:1110] Traceback (most recent call last):
/root/kvcached/experiments/logs_lmcache_v1_debug/kvcached_lmcache_hits_1/prefill.log:(EngineCore pid=7814) Traceback (most recent call last):
/root/kvcached/experiments/logs_lmcache_v1_debug/kvcached_lmcache_hits_1/prefill.log:ERROR 05-12 10:56:41 [async_llm.py:707] Traceback (most recent call last):
/root/kvcached/experiments/logs_lmcache_v1_debug/kvcached_lmcache_hits_1/prefill.log:(EngineCore pid=7814) ERROR 05-12 10:56:41 [async_llm.py:707] vllm.v1.engine.exceptions.EngineDeadError: EngineCore encountered an issue. See stack trace (above) for the root cause.

## Request/Response Files
-rw-r--r-- 1 root root 2949 May 12 10:56 /root/kvcached/experiments/logs_lmcache_v1_debug/kvcached_lmcache_hits_1/request_1_request.json
-rw-r--r-- 1 root root  153 May 12 10:56 /root/kvcached/experiments/logs_lmcache_v1_debug/kvcached_lmcache_hits_1/request_1_response.json
