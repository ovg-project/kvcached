import os
import uuid

import aiohttp
from aiohttp import web


async def health(_request):
    return web.json_response({"ok": True})


def _request_id():
    return f"lmcache-disagg-{uuid.uuid4().hex}"


def _port_list(env_name, default):
    raw = os.environ.get(env_name, str(default))
    return [int(part.strip()) for part in raw.split(",") if part.strip()]


def _attach_prefill_kv_transfer_params(payload, request_id):
    kv_transfer_params = dict(payload.get("kv_transfer_params") or {})
    kv_transfer_params["ret_first_tok"] = True
    kv_transfer_params["disagg_spec"] = {
        "req_id": request_id,
        "receiver_host": os.environ.get("LMCACHE_PD_PEER_HOST", "localhost"),
        "receiver_init_port": _port_list("LMCACHE_PD_PEER_INIT_PORT", 7300),
        "receiver_alloc_port": _port_list("LMCACHE_PD_PEER_ALLOC_PORT", 7400),
    }
    payload["kv_transfer_params"] = kv_transfer_params
    return kv_transfer_params["disagg_spec"]


async def _forward(session, url, payload, request_id):
    headers = {}
    if os.environ.get("FORWARD_X_REQUEST_ID", "1") == "1":
        headers["X-Request-Id"] = request_id
    api_key = os.environ.get("OPENAI_API_KEY")
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"
    async with session.post(url=url, json=payload, headers=headers) as response:
        body = await response.read()
        content_type = response.headers.get("Content-Type", "application/json")
        return response.status, content_type, body


async def handle_request(request):
    original = await request.json()
    prefill = dict(original)
    prefill["max_tokens"] = 1
    if "max_completion_tokens" in prefill:
        prefill["max_completion_tokens"] = 1
    prefill["stream"] = False

    request_id = _request_id()
    disagg_spec = _attach_prefill_kv_transfer_params(prefill, request_id)
    prefill_url = f"http://{os.environ['PREFILL_HTTP']}{request.path}"
    decode_url = f"http://{os.environ['DECODE_HTTP']}{request.path}"
    print(
        f"handle_request request_id={request_id} "
        f"prefill_url={prefill_url} decode_url={decode_url} "
        f"disagg_spec={disagg_spec}",
        flush=True,
    )

    timeout = aiohttp.ClientTimeout(total=6 * 60 * 60)
    async with aiohttp.ClientSession(timeout=timeout) as session:
        prefill_status, _prefill_type, prefill_body = await _forward(
            session, prefill_url, prefill, request_id
        )
        print(
            f"prefill_done request_id={request_id} status={prefill_status} "
            f"bytes={len(prefill_body)}",
            flush=True,
        )
        if prefill_status >= 400:
            return web.Response(
                body=prefill_body,
                status=prefill_status,
                content_type="application/json",
            )

        decode_status, decode_type, decode_body = await _forward(
            session, decode_url, original, request_id
        )
        print(
            f"decode_done request_id={request_id} status={decode_status} "
            f"bytes={len(decode_body)}",
            flush=True,
        )
        return web.Response(
            body=decode_body,
            status=decode_status,
            content_type=decode_type.split(";")[0],
        )


def main():
    app = web.Application()
    app.router.add_get("/health", health)
    app.router.add_post("/v1/completions", handle_request)
    app.router.add_post("/v1/chat/completions", handle_request)
    web.run_app(
        app,
        host=os.environ.get("PROXY_BIND_IP", "0.0.0.0"),
        port=int(os.environ.get("PROXY_PORT", "9100")),
    )


if __name__ == "__main__":
    main()
